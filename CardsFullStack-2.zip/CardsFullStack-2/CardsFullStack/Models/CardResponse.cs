﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CardsFullStack.Models
{
	public class CardResponse
	{
		public string image { get; set; }
		public string value { get; set; }
		public string suit { get; set; }
		public string code { get; set; }
	}
}
