export interface Deck {
  deck_id: String,
  username: String,
  created_at: Date
}
