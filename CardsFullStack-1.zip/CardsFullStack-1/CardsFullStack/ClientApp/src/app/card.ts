export interface Card {
  id: Number,
  deck_id: String,
  image: String,
  cardcode: String,
  username: String,
  created_at: Date
}
